package gameOfLife;

public class GameOfLife {
	public static void main(String[] args) throws InterruptedException {
		Grid grid = new Grid(20, 20);
		
		SquareConfiguration sc = new SquareConfiguration();
		GliderConfiguration gc = new GliderConfiguration();
		PentadecathlonConfiguration pc = new PentadecathlonConfiguration();
		pc.draw(4, 6, grid);
//		sc.draw(2, 2, grid);
		
		grid.print();

		while(true)
		{
			System.out.print("\033[H\033[2J");
			System.out.flush();

			grid.update();
			grid.print();

			Thread.sleep(100);
		}
	}
}
