package gameOfLife;

import processing.core.PApplet;

public class GameOfLifeProcessing extends PApplet {
	public static void main(String[] args) {
		PApplet.main("gameOfLife.GameOfLifeProcessing");
	}

	private int width, height;
	private int cellSize;
	private int interval = 50;
	private int lastUpdate = 0;
	private boolean isPaused = false;
	private Grid grid;

	public void setup() {
		grid = new Grid(width, height, 0.9);

//		SquareConfiguration sc = new SquareConfiguration();
//		GliderConfiguration gc = new GliderConfiguration();
//		PentadecathlonConfiguration pc = new PentadecathlonConfiguration();
//		pc.draw(4, 6, grid);
//
//		gc.draw(40, 40, grid);
	}

	public void settings() {
		width = 500;
		height = 500;
		cellSize = 2;

		size(width*cellSize, height*cellSize);
	}

	public void draw(){
		if(!isPaused && millis() - lastUpdate > interval)
		{
			grid.update();
			lastUpdate = millis();
		}


		if(mousePressed) {
			int gridX = mouseX / cellSize;
			int gridY = mouseY / cellSize;
			
			if(mouseButton == LEFT)
				grid.setState(gridX, gridY, true);
			else if(mouseButton == RIGHT)
				grid.setState(gridX, gridY, false);
		}

		//clearing all
		background(0, 0, 0);
		
		//set color for cells
		fill(102, 255, 20);
		stroke(102, 255, 20);
		
		//draw
		for (int row = 0; row < grid.getWidth(); row++) {
			for (int column = 0; column < grid.getHeight(); column++) {
				boolean isCellAlive = grid.getState(row,column);

				if(isCellAlive)
				{
					rect(row*cellSize,column*cellSize,cellSize,cellSize);
				}
			}

		}
	}
	
	public void keyPressed() {
		if(key == ' ')
		{
			isPaused = !isPaused;
		}
	}
}
