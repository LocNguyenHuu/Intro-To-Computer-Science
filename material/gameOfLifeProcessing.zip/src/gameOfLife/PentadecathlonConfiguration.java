package gameOfLife;

public class PentadecathlonConfiguration {
	private int[][] coordiantes = {
			{0, 0}, {0, 1}, {0, 2},
			{1, 1},
			{2, 1},
			{3, 0}, {3, 1}, {3, 2},
			//4
			{5, 0}, {5, 1}, {5, 2},
			{6, 0}, {6, 1}, {6, 2},
			//7
			{8, 0}, {8, 1}, {8, 2},
			{9, 1},
			{10, 1},
			{11, 0}, {11, 1}, {11, 2},
			};


	public void draw(int i, int j, Grid grid)
	{
		for(int n = 0; n < coordiantes.length; n++)
		{
			int x = coordiantes[n][0]+i;
			int y = coordiantes[n][1]+j;

			grid.setState(x, y, true);
		}
	}
}
