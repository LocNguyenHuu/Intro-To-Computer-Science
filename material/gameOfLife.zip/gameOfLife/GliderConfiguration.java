package gameOfLife;

public class GliderConfiguration {
	private int[][] coordiantes = {{0, 1}, {1, 2}, {2, 0}, {2, 1}, {2, 2}};


	public void draw(int i, int j, Grid grid)
	{
		for(int n = 0; n < 5; n++)
		{
			int x = coordiantes[n][0]+i;
			int y = coordiantes[n][1]+j;

			grid.setState(x, y, true);
		}
	}
}
