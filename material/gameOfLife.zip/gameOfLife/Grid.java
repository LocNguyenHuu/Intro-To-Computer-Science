package gameOfLife;

public class Grid {

	public static void main(String[] args) {
		Grid grid = new Grid(10, 10, 1);
		
		grid.setState(0, 0, true);
		grid.setState(0, 1, true);
		grid.setState(1, 0, true);
		grid.setState(1, 1, true);
		
		grid.print();
		
		System.out.println("--------");
		grid.update();
		grid.print();
	}
	
	
	private boolean[][] alive;
	private int width, height;
//	private char aliveChar = '\u2B1B';
	private char aliveChar = 'o';
	private String deadChar = " ";
	
	public Grid(int[] size)
	{
		this(size[0], size[1]);
	}
	
	public Grid(int w, int h)
	{
		this(w, h, 1);
	}
	
	public Grid(int w, int h, double percentage)
	{
		width = w;
		height = h;
		alive = new boolean[w][h];
		
		fill(percentage);
	}
	
	public void setState(int i, int j, boolean value)
	{
		alive[rowIndexPeriodic(i)][colIndexPeriodic(j)] = value;
	}
	
	public boolean getState(int i, int j)
	{
		return alive[rowIndexPeriodic(i)][colIndexPeriodic(j)];
	}
	
	
	public void fill(double percentage)
	{
		for (int row = 0; row < width; row++) {
			for (int column = 0; column < height; column++) {
				boolean value = Math.random() > percentage;
				setState(row, column, value);
			}
		}
	}
	
	public void print()
	{
		for (int row = 0; row < width; row++) {
			for (int column = 0; column < height; column++) {
				boolean isCellAlive = alive[row][column];
				
				String toPrint;
				if(isCellAlive)
				{
					toPrint = aliveChar +"";
				}
				else
				{
					toPrint = deadChar;
				}

				System.out.print(toPrint);
			}

			System.out.print("\n");
		}
		System.out.print("\n");
	}
	
	public void update()
	{
		boolean[][] newAlive = new boolean[width][height];

		///rules
		for (int row = 0; row < width; row++) {
			for (int column = 0; column < height; column++) {
				boolean isCellAlive = getState(row,column);
				int aliveNeighs = countAliveNeighbours(row, column);

				if(isCellAlive)
				{
					if(aliveNeighs < 2)
						newAlive[row][column] = false;
					else if(aliveNeighs == 2 || aliveNeighs == 3)
						newAlive[row][column] = true;
					else
						newAlive[row][column] = false;
				}
				else
				{
					if(aliveNeighs == 3)
						newAlive[row][column] = true;
				}
			}
		}

		for (int row = 0; row < width; row++) {
			for (int column = 0; column < height; column++) {
				alive[row][column] = newAlive[row][column];
			}
		}
	}
	
	
	private int rowIndexPeriodic(int row)
	{
		int n = width;
		int infRow = (row + n) % n;
		
		return infRow;
	}
	
	private int colIndexPeriodic(int col)
	{
		int n = height;
		int infCol = (col + n) % n;
		
		return infCol;
	}
	
	private int countAliveNeighbours(int i, int j)
	{
		int res = 0;

		int startI = i-1;
		int startJ = j-1;

		int endI = i+1;
		int endJ = j+1;

		for (int row = startI; row <= endI; row++) {
			for (int column = startJ; column <= endJ; column++) {
				if(row == i && column == j)
					continue;
				
				if(getState(row, column))
				{
					res++;
				}
			}
		}

		return res;
	}

}
